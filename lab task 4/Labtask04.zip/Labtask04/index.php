<!DOCTYPE html>
<html>

<head>
    <title>Home Page</title>
</head>

<body>
    <center>
        <table border="1" width="500px">

            <tr>
                <td>
                    <table width="500px">
                        <tr>
                            <td align="Left">
                                <h3><b>XCompany</b></h3>
                            </td>
                            <td align="Right">
                                <a href="index.php">Home</a> |
                                <a href="view/Login.php">Login</a> |
                                <a href="view/Registration.php">Registration</a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <tr>
                <td colspan="2" height="150px">
                    <b>Welcome to xCompany<b>
                </td>
            </tr>

            <tr>
                <td colspan="2">
                    <center>
                    Copyright © 2017
                    </center>
                </td>
            </tr>
        </table>
    </center>
</body>

</html>